from typing import Callable, Literal
import matplotlib.pyplot as plt
import numpy as np
import numpy.typing as npt
import os

def steepest_descent_backtracking(
    f: Callable[[npt.NDArray[np.float64]], np.float64 | float],
    d_f: Callable[[npt.NDArray[np.float64]], npt.NDArray[np.float64]],
    initial_point: npt.NDArray[np.float64],
    alpha0:float = 10.0,
    rho:float = 0.75,
    c:float = 0.001,
    eps:float = 1e-6,
    max_iters:int = 10000,
) -> npt.NDArray[np.float64]:
    x = initial_point
    x_vals, f_vals, grad_norms = [], [], []
    for _ in range(max_iters):
        gradient = d_f(x)
        if np.linalg.norm(gradient) < eps:
            break
        d = -gradient
        alpha = alpha0
        while f(x + alpha * d) > f(x) + c * alpha * np.dot(gradient.T, d):
            alpha *= rho
        x = x + alpha * d
        x_vals.append(x)
        f_vals.append(f(x))
        grad_norms.append(np.linalg.norm(d_f(x)))

    # Ensure the /plots directory exists
    plots_dir = "plots"
    plt.figure(figsize=(18, 6))
    # Plot f(x) vs iterations
    plt.subplot(1, 3, 1)
    plt.plot(f_vals, '-o', markersize=3)
    plt.title('f(x) vs Iterations')
    plt.xlabel('Iteration')
    plt.ylabel('f(x)')

    # Plot |f'(x)| vs iterations
    plt.subplot(1, 3, 2)
    plt.plot(grad_norms, '-o', markersize=3)
    plt.title('|f\'(x)| vs Iterations')
    plt.xlabel('Iteration')
    plt.ylabel('|f\'(x)|')

    # Assuming a 2D function for the contour plot
    if len(initial_point) == 2:
        plt.subplot(1, 3, 3)
        x_vals_arr = np.array(x_vals)
        x1_vals, x2_vals = x_vals_arr[:, 0], x_vals_arr[:, 1]
        x1_range = np.linspace(np.min(x1_vals) - 1, np.max(x1_vals) + 1, 400)
        x2_range = np.linspace(np.min(x2_vals) - 1, np.max(x2_vals) + 1, 400)
        X1, X2 = np.meshgrid(x1_range, x2_range)
        Z = np.array([f(np.array([x1, x2])) for x1, x2 in zip(np.ravel(X1), np.ravel(X2))]).reshape(X1.shape)
        plt.contourf(X1, X2, Z, levels=50, cmap='viridis')
        plt.colorbar()
        plt.plot(x1_vals, x2_vals, '-o', color='red', markersize=5, linewidth=2)
        plt.title('Contour Plot with Update Directions')
        plt.xlabel('x1')
        plt.ylabel('x2')

    plt.tight_layout()
    file_name = f"{f.__name__}_{np.array2string(initial_point).replace(' ', '').replace('[','').replace(']','')}_Backtracking.png"
    plt.savefig(os.path.join(plots_dir, file_name))
    return x


def steepest_descent_Bisection(
    f: Callable[[npt.NDArray[np.float64]], np.float64 | float],
    d_f: Callable[[npt.NDArray[np.float64]], npt.NDArray[np.float64]],
    initial_point: npt.NDArray[np.float64],
    alpha0:float = 1.0,
    c1:float = 0.001,
    c2:float = 0.1,
    eps:float = 1e-6,
    max_iters:int = 10000,
) -> npt.NDArray[np.float64]:
    x = initial_point
    x_vals, f_vals, grad_norms = [], [], []
    for _ in range(max_iters):
        gradient = d_f(x)
        if np.linalg.norm(gradient) < eps:
            break
        d = -gradient
        alpha_low = 0
        alpha_high = 1e6
        alpha = alpha0
        while True:
            if f(x + alpha * d) > f(x) + c1 * alpha * np.dot(d_f(x).T, d):  # Armijo rule violation
                alpha_high = alpha
                alpha = 0.5 * (alpha_low + alpha_high)
            elif np.dot(d_f(x + alpha * d).T, d) < c2 * np.dot(d_f(x).T, d):  # Curvature condition violation
                alpha_low = alpha
                if alpha_high == 1e6:
                    alpha = 2 * alpha_low
                else:
                    alpha = 0.5 * (alpha_low + alpha_high)
            else:
                break
        x = x + alpha * d
        x_vals.append(x)
        f_vals.append(f(x))
        grad_norms.append(np.linalg.norm(d_f(x)))

    # Ensure the /plots directory exists
    plots_dir = "plots"
    plt.figure(figsize=(18, 6))
    # Plot f(x) vs iterations
    plt.subplot(1, 3, 1)
    plt.plot(f_vals, '-o', markersize=3)
    plt.title('Bisection- f(x) vs Iterations')
    plt.xlabel('Iteration')
    plt.ylabel('f(x)')

    # Plot |f'(x)| vs iterations
    plt.subplot(1, 3, 2)
    plt.plot(grad_norms, '-o', markersize=3)
    plt.title('Bisection- |f\'(x)| vs Iterations')
    plt.xlabel('Iteration')
    plt.ylabel('|f\'(x)|')

    # Assuming a 2D function for the contour plot
    if len(initial_point) == 2:
        plt.subplot(1, 3, 3)
        x_vals_arr = np.array(x_vals)
        x1_vals, x2_vals = x_vals_arr[:, 0], x_vals_arr[:, 1]
        x1_range = np.linspace(np.min(x1_vals) - 1, np.max(x1_vals) + 1, 400)
        x2_range = np.linspace(np.min(x2_vals) - 1, np.max(x2_vals) + 1, 400)
        X1, X2 = np.meshgrid(x1_range, x2_range)
        Z = np.array([f(np.array([x1, x2])) for x1, x2 in zip(np.ravel(X1), np.ravel(X2))]).reshape(X1.shape)
        plt.contourf(X1, X2, Z, levels=50, cmap='viridis')
        plt.colorbar()
        plt.plot(x1_vals, x2_vals, '-o', color='red', markersize=5, linewidth=2)
        plt.title('Contour Plot with Update Directions')
        plt.xlabel('x1')
        plt.ylabel('x2')

    plt.tight_layout()
    file_name = f"{f.__name__}_{np.array2string(initial_point).replace(' ', '').replace('[','').replace(']','')}_Bisection.png"
    plt.savefig(os.path.join(plots_dir, file_name))
    return x
def steepest_descent(
    f: Callable[[npt.NDArray[np.float64]], np.float64 | float],
    d_f: Callable[[npt.NDArray[np.float64]], npt.NDArray[np.float64]],
    inital_point: npt.NDArray[np.float64],
    condition: Literal["Backtracking", "Bisection"],
) -> npt.NDArray[np.float64]:
    if condition == "Backtracking":
        return steepest_descent_backtracking(f,d_f,inital_point)
    elif condition == "Bisection":
        return steepest_descent_Bisection(f,d_f,inital_point)
    else:
        pass
    # Complete this function
    # Use file f"plots/{f.__name__}_{np.array2string(inital_point)}_condition_vals.png" for plotting f(x) vs iters
    # Use file f"plots/{f.__name__}_{np.array2string(inital_point)}_condition_grad.png" for plotting |f'(x)| vs iters
    # Use file f"plots/{f.__name__}_{np.array2string(inital_point)}_condition_cont.png" for plotting the contour plot


def pure_newton_method(
    f: Callable[[npt.NDArray[np.float64]], np.float64],
    d_f: Callable[[npt.NDArray[np.float64]], npt.NDArray[np.float64]],
    d2_f: Callable[[npt.NDArray[np.float64]], npt.NDArray[np.float64]],
    initial_point: npt.NDArray[np.float64],
    eps: float = 1e-6,
    max_iters: int = 10000
) -> npt.NDArray[np.float64]:
    x = initial_point
    x_vals, f_vals, grad_norms = [x], [f(x)], [np.linalg.norm(d_f(x))]
    for _ in range(max_iters):
        grad = d_f(x)
        Hessian = d2_f(x)
        if np.linalg.norm(grad) < eps:
            break
        d = -np.linalg.inv(Hessian).dot(grad)
        x = x + d
        x_vals.append(x)
        f_vals.append(f(x))
        grad_norms.append(np.linalg.norm(d_f(x)))
    plots_dir = "plots"
    plt.figure(figsize=(18, 6))
    # Plot f(x) vs iterations
    plt.subplot(1, 3, 1)
    plt.plot(f_vals, '-o', markersize=3)
    plt.title('Pure- f(x) vs Iterations')
    plt.xlabel('Iteration')
    plt.ylabel('f(x)')

    # Plot |f'(x)| vs iterations
    plt.subplot(1, 3, 2)
    plt.plot(grad_norms, '-o', markersize=3)
    plt.title('Pure- |f\'(x)| vs Iterations')
    plt.xlabel('Iteration')
    plt.ylabel('|f\'(x)|')

    # Assuming a 2D function for the contour plot
    if len(initial_point) == 2:
        plt.subplot(1, 3, 3)
        x_vals_arr = np.array(x_vals)
        x1_vals, x2_vals = x_vals_arr[:, 0], x_vals_arr[:, 1]
        x1_range = np.linspace(np.min(x1_vals) - 1, np.max(x1_vals) + 1, 400)
        x2_range = np.linspace(np.min(x2_vals) - 1, np.max(x2_vals) + 1, 400)
        X1, X2 = np.meshgrid(x1_range, x2_range)
        Z = np.array([f(np.array([x1, x2])) for x1, x2 in zip(np.ravel(X1), np.ravel(X2))]).reshape(X1.shape)
        plt.contourf(X1, X2, Z, levels=50, cmap='viridis')
        plt.colorbar()
        plt.plot(x1_vals, x2_vals, '-o', color='red', markersize=5, linewidth=2)
        plt.title('Contour Plot with Update Directions')
        plt.xlabel('x1')
        plt.ylabel('x2')

    plt.tight_layout()
    file_name = f"{f.__name__}_{np.array2string(initial_point).replace(' ', '').replace('[','').replace(']','')}_Pure.png"
    plt.savefig(os.path.join(plots_dir, file_name))
    return x

def damped_newton_method(
    f: Callable[[npt.NDArray[np.float64]], np.float64],
    d_f: Callable[[npt.NDArray[np.float64]], npt.NDArray[np.float64]],
    d2_f: Callable[[npt.NDArray[np.float64]], npt.NDArray[np.float64]],
    initial_point: npt.NDArray[np.float64],
    eps: float = 1e-6,
    max_iters: int = 10000,
    damping_factor: float = 0.5
) -> npt.NDArray[np.float64]:
    x = initial_point.copy()
    x_vals, f_vals, grad_norms = [x], [f(x)], [np.linalg.norm(d_f(x))]
    for _ in range(max_iters):
        grad = d_f(x)
        Hessian = d2_f(x)
        if np.linalg.norm(grad) < eps:
            break
        try:
            d = -np.linalg.inv(Hessian).dot(grad)
        except np.linalg.LinAlgError:
            # Hessian is singular, fall back to a smaller step
            d = -grad
        t = 1
        while f(x + t * d) > f(x) + 0.5 * t * d_f(x).T @ d:
            t = t * 0.5
        x = x + t * d
        x_vals.append(x)
        f_vals.append(f(x))
        grad_norms.append(np.linalg.norm(d_f(x)))

    # Plotting and diagnostics can be added here as needed
    plots_dir = "plots"
    plt.figure(figsize=(18, 6))
    # Plot f(x) vs iterations
    plt.subplot(1, 3, 1)
    plt.plot(f_vals, '-o', markersize=3)
    plt.title('Damped- f(x) vs Iterations')
    plt.xlabel('Iteration')
    plt.ylabel('f(x)')

    # Plot |f'(x)| vs iterations
    plt.subplot(1, 3, 2)
    plt.plot(grad_norms, '-o', markersize=3)
    plt.title('Damped- |f\'(x)| vs Iterations')
    plt.xlabel('Iteration')
    plt.ylabel('|f\'(x)|')

    # Assuming a 2D function for the contour plot
    if len(initial_point) == 2:
        plt.subplot(1, 3, 3)
        x_vals_arr = np.array(x_vals)
        x1_vals, x2_vals = x_vals_arr[:, 0], x_vals_arr[:, 1]
        x1_range = np.linspace(np.min(x1_vals) - 1, np.max(x1_vals) + 1, 400)
        x2_range = np.linspace(np.min(x2_vals) - 1, np.max(x2_vals) + 1, 400)
        X1, X2 = np.meshgrid(x1_range, x2_range)
        Z = np.array([f(np.array([x1, x2])) for x1, x2 in zip(np.ravel(X1), np.ravel(X2))]).reshape(X1.shape)
        plt.contourf(X1, X2, Z, levels=50, cmap='viridis')
        plt.colorbar()
        plt.plot(x1_vals, x2_vals, '-o', color='red', markersize=5, linewidth=2)
        plt.title('Contour Plot with Update Directions')
        plt.xlabel('x1')
        plt.ylabel('x2')

    plt.tight_layout()
    file_name = f"{f.__name__}_{np.array2string(initial_point).replace(' ', '').replace('[','').replace(']','')}_Damped.png"
    plt.savefig(os.path.join(plots_dir, file_name))
    return x

def levenberg_marquardt_newton_method(
    f: Callable[[npt.NDArray[np.float64]], np.float64],
    d_f: Callable[[npt.NDArray[np.float64]], npt.NDArray[np.float64]],
    d2_f: Callable[[npt.NDArray[np.float64]], npt.NDArray[np.float64]],
    initial_point: npt.NDArray[np.float64],
    eps: float = 1e-6,
    max_iters: int = 10000,
    lambda_factor: float = 0.01
) -> npt.NDArray[np.float64]:
    x = initial_point
    x_vals, f_vals, grad_norms = [x], [f(x)], [np.linalg.norm(d_f(x))]
    for _ in range(max_iters):
        grad = d_f(x)
        Hessian = d2_f(x)
        if np.linalg.norm(grad) < eps:
            break
        eigen_vals = np.linalg.eigvals(Hessian)
        lamda = np.min(eigen_vals)
        if lamda <= 0:
            mu = -lamda + 0.1
            d = -np.linalg.inv(Hessian + mu * np.eye(len(Hessian))).dot(grad)
        else:
            d = -np.linalg.inv(Hessian).dot(grad)
        x = x + d
        x_vals.append(x)
        f_vals.append(f(x))
        grad_norms.append(np.linalg.norm(d_f(x)))
    # plots
    plots_dir = "plots"
    plt.figure(figsize=(18, 6))
    # Plot f(x) vs iterations
    plt.subplot(1, 3, 1)
    plt.plot(f_vals, '-o', markersize=3)
    plt.title('Damped- f(x) vs Iterations')
    plt.xlabel('Iteration')
    plt.ylabel('f(x)')

    # Plot |f'(x)| vs iterations
    plt.subplot(1, 3, 2)
    plt.plot(grad_norms, '-o', markersize=3)
    plt.title('Damped- |f\'(x)| vs Iterations')
    plt.xlabel('Iteration')
    plt.ylabel('|f\'(x)|')

    # Assuming a 2D function for the contour plot
    if len(initial_point) == 2:
        plt.subplot(1, 3, 3)
        x_vals_arr = np.array(x_vals)
        x1_vals, x2_vals = x_vals_arr[:, 0], x_vals_arr[:, 1]
        x1_range = np.linspace(np.min(x1_vals) - 1, np.max(x1_vals) + 1, 400)
        x2_range = np.linspace(np.min(x2_vals) - 1, np.max(x2_vals) + 1, 400)
        X1, X2 = np.meshgrid(x1_range, x2_range)
        Z = np.array([f(np.array([x1, x2])) for x1, x2 in zip(np.ravel(X1), np.ravel(X2))]).reshape(X1.shape)
        plt.contourf(X1, X2, Z, levels=50, cmap='viridis')
        plt.colorbar()
        plt.plot(x1_vals, x2_vals, '-o', color='red', markersize=5, linewidth=2)
        plt.title('Contour Plot with Update Directions')
        plt.xlabel('x1')
        plt.ylabel('x2')

    plt.tight_layout()
    file_name = f"{f.__name__}_{np.array2string(initial_point).replace(' ', '').replace('[','').replace(']','')}_Damped.png"
    plt.savefig(os.path.join(plots_dir, file_name))
    return x

def combined_newton_method(
    f: Callable[[npt.NDArray[np.float64]], np.float64],
    d_f: Callable[[npt.NDArray[np.float64]], npt.NDArray[np.float64]],
    d2_f: Callable[[npt.NDArray[np.float64]], npt.NDArray[np.float64]],
    initial_point: npt.NDArray[np.float64],
    eps: float = 1e-6,
    c: float = 0.001,
    max_iters: int = 10000,
    damping_factor:float = 0.001,
) -> npt.NDArray[np.float64]:
    x = initial_point
    x_vals, f_vals, grad_norms = [x], [f(x)], [np.linalg.norm(d_f(x))]
    for _ in range(max_iters):
        grad = d_f(x)
        Hessian = d2_f(x)
        if np.linalg.norm(grad) < eps:
            break
        eigen_vals = np.linalg.eigvals(Hessian)
        lamda = np.min(eigen_vals)
        if lamda <= 0:
            mu = -lamda + 0.1
            d = -np.linalg.inv(Hessian + mu * np.eye(len(Hessian))).dot(grad)
        else:
            d = -np.linalg.inv(Hessian).dot(grad)
        alpha = 10
        while f(x + alpha * d) > f(x) + c * alpha * d_f(x).dot(d):
            alpha *= 0.75
        x = x + alpha * d
        x_vals.append(x)
        f_vals.append(f(x))
        grad_norms.append(np.linalg.norm(d_f(x)))
    # plots
    plots_dir = "plots"
    plt.figure(figsize=(18, 6))
    # Plot f(x) vs iterations
    plt.subplot(1, 3, 1)
    plt.plot(f_vals, '-o', markersize=3)
    plt.title('Damped- f(x) vs Iterations')
    plt.xlabel('Iteration')
    plt.ylabel('f(x)')

    # Plot |f'(x)| vs iterations
    plt.subplot(1, 3, 2)
    plt.plot(grad_norms, '-o', markersize=3)
    plt.title('Damped- |f\'(x)| vs Iterations')
    plt.xlabel('Iteration')
    plt.ylabel('|f\'(x)|')

    # Assuming a 2D function for the contour plot
    if len(initial_point) == 2:
        plt.subplot(1, 3, 3)
        x_vals_arr = np.array(x_vals)
        x1_vals, x2_vals = x_vals_arr[:, 0], x_vals_arr[:, 1]
        x1_range = np.linspace(np.min(x1_vals) - 1, np.max(x1_vals) + 1, 400)
        x2_range = np.linspace(np.min(x2_vals) - 1, np.max(x2_vals) + 1, 400)
        X1, X2 = np.meshgrid(x1_range, x2_range)
        Z = np.array([f(np.array([x1, x2])) for x1, x2 in zip(np.ravel(X1), np.ravel(X2))]).reshape(X1.shape)
        plt.contourf(X1, X2, Z, levels=50, cmap='viridis')
        plt.colorbar()
        plt.plot(x1_vals, x2_vals, '-o', color='red', markersize=5, linewidth=2)
        plt.title('Contour Plot with Update Directions')
        plt.xlabel('x1')
        plt.ylabel('x2')

    plt.tight_layout()
    file_name = f"{f.__name__}_{np.array2string(initial_point).replace(' ', '').replace('[','').replace(']','')}_Damped.png"
    plt.savefig(os.path.join(plots_dir, file_name))
    return x

# Do not rename or delete this function
def newton_method(
    f: Callable[[npt.NDArray[np.float64]], np.float64 | float],
    d_f: Callable[[npt.NDArray[np.float64]], npt.NDArray[np.float64]],
    d2_f: Callable[[npt.NDArray[np.float64]], npt.NDArray[np.float64]],
    inital_point: npt.NDArray[np.float64],
    condition: Literal["Pure", "Damped", "Levenberg-Marquardt", "Combined"],
) -> npt.NDArray[np.float64]:
    if condition == "Pure":
        return pure_newton_method(f,d_f, d2_f, inital_point)
    elif condition == "Damped":
        return damped_newton_method(f, d_f, d2_f, inital_point)
    elif condition == "Levenberg-Marquardt":
        return levenberg_marquardt_newton_method(f,d_f, d2_f, inital_point)
    elif condition == "Combined":
        return combined_newton_method(f,d_f,d2_f, inital_point)
    else:
        pass

